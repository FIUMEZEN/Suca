<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\CartController;

Route::apiResource('items', ItemController::class);
Route::apiResource('carts', CartController::class);

Route::post('/carts/{cart}/add', [CartController::class, 'addItem']);
Route::post('/carts/{cart}/remove', [CartController::class, 'removeItem']);

Route::get('/ping', function () {
    return response()->json(['pong' => true]);
});
