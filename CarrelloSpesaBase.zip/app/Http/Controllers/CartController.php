<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Item;

class CartController extends Controller
{
    public function index()
    {
        return Cart::with('items')->get();
    }

    public function store(Request $request)
    {
        return Cart::create();
    }

    public function show(Cart $cart)
    {
        return $cart->load('items');
    }

    public function update(Request $request, Cart $cart)
    {
        return $cart;
    }

    public function destroy(Cart $cart)
    {
        $cart->delete();
        return response()->json(null, 204);
    }

    public function addItem(Request $request, Cart $cart)
    {
        $request->validate(['item_id' => 'required|exists:items,id']);
        $cart->items()->attach($request->item_id);
        return $cart->load('items');
    }

    public function removeItem(Request $request, Cart $cart)
    {
        $request->validate(['item_id' => 'required|exists:items,id']);
        $cart->items()->detach($request->item_id);
        return $cart->load('items');
    }
}
