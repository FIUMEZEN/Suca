<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Item;

class ItemSeeder extends Seeder
{
    public function run()
    {
        Item::insert([
            ['name' => 'Laptop', 'price' => 1200.00, 'description' => 'Laptop da lavoro'],
            ['name' => 'Smartphone', 'price' => 800.00, 'description' => 'Telefono 5G'],
            ['name' => 'Monitor 27"', 'price' => 300.00, 'description' => 'Display 4K'],
            ['name' => 'Mouse', 'price' => 25.00, 'description' => 'Mouse wireless'],
            ['name' => 'Tastiera', 'price' => 45.00, 'description' => 'Tastiera meccanica'],
        ]);
    }
}
